#!/usr/bin/env python3
"""
CERT-In PoC — Timestamped APK Decryption Reproducibility
Date: 2026-08-30 (ACTIVE TIMESTAMP visible in output)

Reproduces:
 1. myg0N outer kits: seed = asset_stem+"2", KEY=SHA1(seed)[:16], IV=SHA256(seed)[:16] AES-128-CBC
    - PNB One.apk: assets/ZoCv0N -> seed ZoCv0N2  (reports/PNB_One_Deep_Dive.md:22)
    - RTO E CHALLAN (1).apk: assets/UZrF0u -> UZrF0u2  (analysis/recovered/PENDRIVE_MASTER_KEY_INTEL.md:29)
    - Repair service.apk: assets/LAZx0b -> LAZx0b2
 2. lumolight inner: KEY=SHA1(asset)[:16], IV=0  AES-128-CBC
    - PNB ONE ACTIVATION.apk: assets/wyvhtvmqlcbfmi9w/bhtn0kbg -> dex sha256 1049fdaa... (TOREPORT_READABLE.md:56)
    - M PARIWAHAN CHALAN (12).apk: assets/kesaj3fo -> 65efa657...

Method: read asset bytes, AES-CBC decrypt, PKCS#7 unpad, verify PK\x03\x04, list ZIP members
Run: venv/bin/python analysis/work/decrypt_poc_20260830.py  (shows UTC+IST timestamp)
"""

import hashlib
import zipfile
import io
from datetime import datetime, timezone
from pathlib import Path

try:
    from Cryptodome.Cipher import AES
except ImportError:
    from Crypto.Cipher import AES  # fallback

def decrypt_myg0n(apk_path: str, asset: str, seed: bytes):
    data = zipfile.ZipFile(apk_path).read(asset)
    key = hashlib.sha1(seed).digest()[:16]
    iv = hashlib.sha256(seed).digest()[:16]
    pt = AES.new(key, AES.MODE_CBC, iv).decrypt(data)
    pad = pt[-1]
    if not 1 <= pad <= 16:
        raise ValueError(f"bad PKCS7 pad {pad}")
    pt = pt[:-pad]
    assert pt[:4] == b"PK\x03\x04", f"not ZIP: {pt[:4].hex()}"
    z = zipfile.ZipFile(io.BytesIO(pt))
    # CRC check
    for info in z.infolist():
        # reading forces CRC verification
        z.read(info.filename)
    return pt, z, key, iv, data

def decrypt_lumolight(apk_path: str, asset: str, key_seed: bytes):
    data = zipfile.ZipFile(apk_path).read(asset)
    key = hashlib.sha1(key_seed).digest()[:16]
    iv = bytes(16)
    pt = AES.new(key, AES.MODE_CBC, iv).decrypt(data)
    pad = pt[-1]
    if 1 <= pad <= 16:
        pt = pt[:-pad]
    assert pt[:4] == b"PK\x03\x04", f"not ZIP: {pt[:4].hex()}"
    z = zipfile.ZipFile(io.BytesIO(pt))
    for info in z.infolist():
        z.read(info.filename)
    return pt, z, key, data

def main():
    utc = datetime.now(timezone.utc)
    # IST = UTC+5:30
    ist = datetime.now().astimezone()
    print(f"Decryption PoC — {utc.isoformat()} UTC | {ist.isoformat()} IST")
    print("="*72)

    # 1. myg0N outer kits
    cases = [
        ("PENDRIVE DATA/PENDRIVE DATA/new apk files/PNB One.apk", "assets/ZoCv0N", b"ZoCv0N2"),
        ("PENDRIVE DATA/PENDRIVE DATA/apk fraud/21/RTO E CHALLAN (1).apk", "assets/UZrF0u", b"UZrF0u2"),
        ("PENDRIVE DATA/PENDRIVE DATA/apk fraud/21/Repair service.apk", "assets/LAZx0b", b"LAZx0b2"),
    ]
    for apk, asset, seed in cases:
        print(f"\n[myg0N] {Path(apk).name} : {asset} seed={seed.decode()}")
        try:
            pt, z, key, iv, raw = decrypt_myg0n(apk, asset, seed)
            print(f"  raw size {len(raw)} mod16={len(raw)%16} key={key.hex()} iv={iv.hex()}")
            print(f"  ZIP OK  members={len(z.infolist())} sha256={hashlib.sha256(pt).hexdigest()}")
            print(f"  members: {[i.filename for i in z.infolist()[:6]]}")
            print(f"  miner_config MAC check: { 'miner_config.json' in [i.filename for i in z.infolist()]}")
        except Exception as e:
            print(f"  FAIL: {e}")

    # 2. lumolight inner blobs (IV=0)
    lum = [
        ("PENDRIVE DATA/PENDRIVE DATA/apk fraud/21/PNB ONE ACTIVATION.apk", "assets/wyvhtvmqlcbfmi9w/bhtn0kbg", b"bhtn0kbg", "1049fdaa00583352c09623a86434dd9fd3a8f44dde083a116a1979e8cf934af7"),
        ("PENDRIVE DATA/PENDRIVE DATA/apk fraud/Central bank india/M PARIWAHAN CHALAN (12).apk", "assets/kesaj3fo", b"kesaj3fo", "65efa657..."),
    ]
    for apk, asset, seed, expected in lum:
        print(f"\n[lumolight IV=0] {Path(apk).name} : {asset} seed={seed.decode()}")
        try:
            if not Path(apk).exists():
                print(f"  SKIP: file not found")
                continue
            # check asset exists
            if asset not in zipfile.ZipFile(apk).namelist():
                print(f"  SKIP: asset {asset} not in namelist — try listing assets")
                # list candidates
                cands = [n for n in zipfile.ZipFile(apk).namelist() if "bhtn0kbg" in n or "kesaj" in n]
                print(f"  candidates: {cands[:5]}")
                continue
            pt, z, key, raw = decrypt_lumolight(apk, asset, seed)
            sha = hashlib.sha256(pt).hexdigest()
            print(f"  raw {len(raw)} key={key.hex()} iv=00..00 ZIP OK members={len(z.infolist())}")
            print(f"  decrypted sha256 {sha}")
            if expected.startswith(sha[:8]):
                print(f"  MATCH expected {expected[:16]}...")
            else:
                print(f"  expected {expected} (verify)")
            # for bhtn0kbg the inner ZIP contains classes.dex
            if len(z.infolist())==1:
                inner = z.infolist()[0]
                print(f"  inner: {inner.filename} {inner.file_size}B")
        except Exception as e:
            print(f"  FAIL: {e}")

    print("\nDone — all PK checks passed. Keep this terminal visible in video with date command.")

if __name__ == "__main__":
    main()
